﻿using System;
using System.Windows.Forms;


namespace RTS_Gade_Home_
{
    public partial class frmGame : Form
    {
        
        
        private Map map;
        private GameEngine engine;
        private int mapXSize =20, mapYSize = 20;

        public frmGame()
        {
            InitializeComponent();          

        }
                
        public void InitialiseGame()//Called from start button event
        {
            engine = new GameEngine();//create GameEngine instance
            map = new Map(6, 3, mapYSize, mapXSize, 6);//create Map instance
            engine.MapHandle = map;
            GameEngine.Rounds = 0;//Reset rounds counter
            
            map.SpawnUnits();
            map.SpawnBuildings();
            tmrTimer.Enabled = true;//Start timer
            
        }

        public void GameLoop()
        {
            engine.GameUpdater();
            lblRound.Text = "Round:" + GameEngine.Rounds;
            lblMap.Text = map.UpdateMap();
            rtfUnitInfo.Text = engine.UnitInfo;
            rtfBuildingInfo.Text = engine.BuildingInfo;
            lblResourses.Text = engine.TeamResources;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            InitialiseGame();
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            tmrTimer.Enabled = !tmrTimer.Enabled;//Pause Timer
        }        

        private void timerTick(object sender, EventArgs e)
        {
            GameLoop();//Execute game updates
        }
                    

        private void btnLoad_Click(object sender, EventArgs e)
        {
            map.LoadGame();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            engine.SaveGame();
            
        }

       

        private void rdb_CheckedChanged(object sender, EventArgs e)
        {
            if (rdb16X18.Checked)
            {
                rdb30X30.Checked = false;
                rdb10X10.Checked = false;
                rdb20X20.Checked = false;
                mapXSize = 16;
                mapYSize = 18;
            }
            else if(rdb10X10.Checked)
            {
                rdb30X30.Checked = false;
                rdb16X18.Checked = false;
                rdb20X20.Checked = false;
                mapXSize = 10;
                mapYSize = 10;
            }
            else if (rdb30X30.Checked)
            {
                rdb10X10.Checked = false;
                rdb16X18.Checked = false;
                rdb20X20.Checked = false;
                mapXSize = 30;
                mapYSize = 30;
            }
            else
            {
                rdb30X30.Checked = false;
                rdb16X18.Checked = false;
                rdb10X10.Checked = false;
                mapXSize = 20;
                mapYSize = 20;
            }
        }
    }
}
