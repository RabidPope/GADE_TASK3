﻿namespace RTS_Gade_Home_
{
    partial class frmGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblMap = new System.Windows.Forms.Label();
            this.lblRound = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.rtfUnitInfo = new System.Windows.Forms.RichTextBox();
            this.tmrTimer = new System.Windows.Forms.Timer(this.components);
            this.lblUnits = new System.Windows.Forms.Label();
            this.rtfBuildingInfo = new System.Windows.Forms.RichTextBox();
            this.lblBuildings = new System.Windows.Forms.Label();
            this.lblResourses = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.rdb16X18 = new System.Windows.Forms.RadioButton();
            this.rdb20X20 = new System.Windows.Forms.RadioButton();
            this.rdb10X10 = new System.Windows.Forms.RadioButton();
            this.rdb30X30 = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lblMap
            // 
            this.lblMap.AutoSize = true;
            this.lblMap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMap.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMap.Location = new System.Drawing.Point(116, 59);
            this.lblMap.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblMap.Name = "lblMap";
            this.lblMap.Padding = new System.Windows.Forms.Padding(1, 0, 0, 0);
            this.lblMap.Size = new System.Drawing.Size(57, 29);
            this.lblMap.TabIndex = 0;
            this.lblMap.Text = "Map";
            // 
            // lblRound
            // 
            this.lblRound.AutoSize = true;
            this.lblRound.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRound.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRound.Location = new System.Drawing.Point(116, 18);
            this.lblRound.Name = "lblRound";
            this.lblRound.Size = new System.Drawing.Size(112, 33);
            this.lblRound.TabIndex = 0;
            this.lblRound.Text = "Round:";
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(12, 20);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(89, 47);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnPause
            // 
            this.btnPause.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPause.Location = new System.Drawing.Point(12, 80);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(89, 44);
            this.btnPause.TabIndex = 2;
            this.btnPause.Text = "Pause";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // rtfUnitInfo
            // 
            this.rtfUnitInfo.Location = new System.Drawing.Point(1070, 59);
            this.rtfUnitInfo.Name = "rtfUnitInfo";
            this.rtfUnitInfo.Size = new System.Drawing.Size(330, 183);
            this.rtfUnitInfo.TabIndex = 3;
            this.rtfUnitInfo.Text = "";
            // 
            // tmrTimer
            // 
            this.tmrTimer.Interval = 1000;
            this.tmrTimer.Tick += new System.EventHandler(this.timerTick);
            // 
            // lblUnits
            // 
            this.lblUnits.AutoSize = true;
            this.lblUnits.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUnits.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnits.Location = new System.Drawing.Point(1072, 24);
            this.lblUnits.Name = "lblUnits";
            this.lblUnits.Size = new System.Drawing.Size(96, 33);
            this.lblUnits.TabIndex = 0;
            this.lblUnits.Text = "Units";
            // 
            // rtfBuildingInfo
            // 
            this.rtfBuildingInfo.Location = new System.Drawing.Point(1072, 313);
            this.rtfBuildingInfo.Name = "rtfBuildingInfo";
            this.rtfBuildingInfo.Size = new System.Drawing.Size(328, 183);
            this.rtfBuildingInfo.TabIndex = 3;
            this.rtfBuildingInfo.Text = "";
            // 
            // lblBuildings
            // 
            this.lblBuildings.AutoSize = true;
            this.lblBuildings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBuildings.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuildings.Location = new System.Drawing.Point(1072, 277);
            this.lblBuildings.Name = "lblBuildings";
            this.lblBuildings.Size = new System.Drawing.Size(160, 33);
            this.lblBuildings.TabIndex = 0;
            this.lblBuildings.Text = "Buildings";
            // 
            // lblResourses
            // 
            this.lblResourses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResourses.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResourses.Location = new System.Drawing.Point(900, 59);
            this.lblResourses.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblResourses.Name = "lblResourses";
            this.lblResourses.Size = new System.Drawing.Size(166, 216);
            this.lblResourses.TabIndex = 0;
            this.lblResourses.Text = "Resources";
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(12, 206);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(89, 47);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoad.Location = new System.Drawing.Point(12, 265);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(89, 47);
            this.btnLoad.TabIndex = 1;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // rdb16X18
            // 
            this.rdb16X18.AutoSize = true;
            this.rdb16X18.Location = new System.Drawing.Point(12, 396);
            this.rdb16X18.Name = "rdb16X18";
            this.rdb16X18.Size = new System.Drawing.Size(62, 17);
            this.rdb16X18.TabIndex = 4;
            this.rdb16X18.Text = "16 X 18";
            this.rdb16X18.UseVisualStyleBackColor = true;
            this.rdb16X18.CheckedChanged += new System.EventHandler(this.rdb_CheckedChanged);
            this.rdb16X18.Click += new System.EventHandler(this.rdb_CheckedChanged);
            // 
            // rdb20X20
            // 
            this.rdb20X20.AutoSize = true;
            this.rdb20X20.Checked = true;
            this.rdb20X20.Location = new System.Drawing.Point(12, 419);
            this.rdb20X20.Name = "rdb20X20";
            this.rdb20X20.Size = new System.Drawing.Size(62, 17);
            this.rdb20X20.TabIndex = 4;
            this.rdb20X20.TabStop = true;
            this.rdb20X20.Text = "20 X 20";
            this.rdb20X20.UseVisualStyleBackColor = true;
            this.rdb20X20.Click += new System.EventHandler(this.rdb_CheckedChanged);
            // 
            // rdb10X10
            // 
            this.rdb10X10.AutoSize = true;
            this.rdb10X10.Location = new System.Drawing.Point(12, 373);
            this.rdb10X10.Name = "rdb10X10";
            this.rdb10X10.Size = new System.Drawing.Size(62, 17);
            this.rdb10X10.TabIndex = 4;
            this.rdb10X10.Text = "10 X 10";
            this.rdb10X10.UseVisualStyleBackColor = true;
            this.rdb10X10.CheckedChanged += new System.EventHandler(this.rdb_CheckedChanged);
            this.rdb10X10.Click += new System.EventHandler(this.rdb_CheckedChanged);
            // 
            // rdb30X30
            // 
            this.rdb30X30.AutoSize = true;
            this.rdb30X30.Location = new System.Drawing.Point(12, 442);
            this.rdb30X30.Name = "rdb30X30";
            this.rdb30X30.Size = new System.Drawing.Size(62, 17);
            this.rdb30X30.TabIndex = 4;
            this.rdb30X30.Text = "30 X 30";
            this.rdb30X30.UseVisualStyleBackColor = true;
            this.rdb30X30.Click += new System.EventHandler(this.rdb_CheckedChanged);
            // 
            // frmGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1412, 762);
            this.Controls.Add(this.rdb30X30);
            this.Controls.Add(this.rdb20X20);
            this.Controls.Add(this.rdb10X10);
            this.Controls.Add(this.rdb16X18);
            this.Controls.Add(this.rtfBuildingInfo);
            this.Controls.Add(this.rtfUnitInfo);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblBuildings);
            this.Controls.Add(this.lblUnits);
            this.Controls.Add(this.lblRound);
            this.Controls.Add(this.lblResourses);
            this.Controls.Add(this.lblMap);
            this.Name = "frmGame";
            this.Text = "RTS Sim";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnPause;
        public System.Windows.Forms.Label lblMap;
        private System.Windows.Forms.Timer tmrTimer;
        public System.Windows.Forms.Label lblRound;
        public System.Windows.Forms.RichTextBox rtfUnitInfo;
        public System.Windows.Forms.Label lblUnits;
        public System.Windows.Forms.RichTextBox rtfBuildingInfo;
        public System.Windows.Forms.Label lblBuildings;
        public System.Windows.Forms.Label lblResourses;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.RadioButton rdb16X18;
        private System.Windows.Forms.RadioButton rdb20X20;
        private System.Windows.Forms.RadioButton rdb10X10;
        private System.Windows.Forms.RadioButton rdb30X30;
    }
}

